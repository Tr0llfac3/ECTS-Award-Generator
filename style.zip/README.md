# ECTS Award Gen
## Important Links
    - [ClickUp](https://app.clickup.com/42659169/dashboards/18nvb1-62)